---
title: Rivet Rocket Coloring Page
theme: rocket-coloring-pages
slug: rivet-rocket
description: "A rocket with rivets, one window, and one star. For about ages 4 to 5."
alt: "Rocket with rivet dots, one porthole, a small flame, one star, and two small clouds."
parentNote: "The rivets are small dots. Fill the big panels first, and the dots can be a last pass."
order: 24
difficulty: easy
age: "4-5"
---
